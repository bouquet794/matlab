[x,fs]=audioread('dtmf-test2.wav');
x=x(:,1);
 y = double(x);
%  y = y / max(abs(y));
 N=length(y);
 time1=(0:N-1)/fs;%计算出信号的时间坐标
 
%常数设置
FrameLen = 240;%帧长为240点
FrameInc = 80;%帧移为80点
 
amp1 = 10;%初始短时能量高门限
amp2 = 2;%初始短时能量低门限
zcr1 = 10;%初始短时过零率高门限
zcr2 = 5;%初始短时过零率低门限
 
maxsilence = 8;  % 8*10ms  = 80ms
%语音段中允许的最大静音长度，如果语音段中的静音帧数未超过此值，则认为语音还没结束；如果超过了
%该值，则对语音段长度count进行判断，若count<minlen，则认为前面的语音段为噪音，舍弃，跳到静音
%状态0；若count>minlen，则认为语音段结束；

minlen  = 15;    % 15*10ms = 150ms
%语音段的最短长度，若语音段长度小于此值，则认为其为一段噪音

status  = 0;     %初始状态为静音状态
count   = 0;     %初始语音段长度为0
silence = 0;     %初始静音段长度为0
 
%计算过零率
tmp1  = enframe(y(1:end-1), FrameLen, FrameInc);%分帧，所得矩阵为fix（（x(1:end-1)-FrameLen+FrameInc）/FrameInc）*FrameLen
tmp2  = enframe(y(2:end)  , FrameLen, FrameInc);%分帧，所得矩阵为fix（（x(2:end)-FrameLen+FrameInc）/FrameInc）*FrameLen
signs = (tmp1.*tmp2)<0;%tmp1.*tmp2所得矩阵小于等于零的赋值为1，大于零的赋值为0
diffs = (tmp1 -tmp2)>0.02;%tmp1-tmp2所得矩阵小于0.02的赋值为0，大于等于0.02的赋值为1
zcr   = sum(signs.*diffs, 2);
 
%计算短时能量
%amp = sum(abs(enframe(filter([1 -0.9375], 1, x), FrameLen, FrameInc)), 2);
amp = sum(abs(enframe(y, FrameLen, FrameInc)), 2);
 
%调整能量门限
amp1 = min(amp1, max(amp)/4);
amp2 = min(amp2, max(amp)/8);
 
%开始端点检测
x1 = 0;
x2 = 0;
for n=1:length(zcr) %length（zcr）得到的是整个信号的帧数
   goto = 0;
   switch status
   case {0,1}                   % 0 = 静音, 1 = 可能开始
      if amp(n) > amp1          % 确信进入语音段
         x1 = max(n-count-1,1);
         status  = 2;
         silence = 0;
         count   = count + 1;
      elseif amp(n) > amp2 || ... % 可能处于语音段
             zcr(n) > zcr2
         status = 1;
         count  = count + 1;
      else                       % 静音状态
         status  = 0;
         count   = 0;
      end
   case 2                      % 2 = 语音段
      if amp(n) > amp2 || ...     % 保持在语音段
         zcr(n) > zcr2
         count = count + 1;
      else                       % 语音将结束
         silence = silence+1;
         if silence < maxsilence % 静音还不够长，尚未结束
            count  = count + 1;
         elseif count < minlen   % 语音长度太短，认为是噪声
            status  = 0;
            silence = 0;
            count   = 0;
         else                    % 语音结束
            status  = 3;
         end
      end
   case 3
      break;
   end
end  
Z=length(zcr);
k=1;
for i=1:Z
    if zcr(i)>15
        Z(k)=i;
        k=k+1;
    end
end

X1=round(N/length(zcr))*Z(1);
X2=round(N/length(zcr))*Z(k-1);

 [a,b,c]=spectrogram(x(X1:X2),hann(512),256,512,fs,'yaxis');
[cx,cy]=size(c);
time=[0.04,0.22,0.42,0.60,0.81,1,1.16,1.35,1.55];
s=1;
A=sqrt(abs(a).^2);
fprintf('your phone numbers are : ');
for i=1:9
    for j=1:cy-1
        if time(i)>c(j)&&time(i)<c(j+1)
            n=j+1;
        end
    end

        [pks,peak_r]=findpeaks(A(:,n),'minpeakheight',1);
        [MAX,sub]=sort(peak_r(:));
        h=length(MAX);
        p=1;
 
        for m=h:-1:1
            if b(MAX(m))>650&&b(MAX(m))<1500
                frequence(p)=b(MAX(m));
                p=p+1;
            end
        end
        if((frequence(1)<1239&&frequence(1)>1179&&frequence(2)<727&&frequence(2)>667)||(frequence(2)<1239&&frequence(2)>1179&&frequence(1)<727&&frequence(1)>667))
            fprintf('1');
        elseif((frequence(1)<1366&&frequence(1)>1306&&frequence(2)<727&&frequence(2)>667)||(frequence(2)<1366&&frequence(2)>1306&&frequence(1)<727&&frequence(1)>667))
            fprintf('2');
        elseif((frequence(1)<1507&&frequence(1)>1447&&frequence(2)<727&&frequence(2)>667)||(frequence(2)<1507&&frequence(2)>1447&&frequence(1)<727&&frenquence(1)>667))
            fprintf('3');
        elseif((frequence(1)<1239&&frequence(1)>1179&&frequence(2)<800&&frequence(2)>740)||(frequence(2)<1239&&frequence(2)>1179&&frequence(1)<800&&frequence(1)>740))
            fprintf('4');
        elseif((frequence(1)<1366&&frequence(1)>1306&&frequence(2)<800&&frequence(2)>740)||(frequence(2)<1366&&frequence(2)>1306&&frequence(1)<800&&frequence(1)>740))
            fprintf('5');
        elseif((frequence(1)<1507&&frequence(1)>1447&&frequence(2)<800&&frequence(2)>740)||(frequence(2)<1507&&frequence(2)>1447&&frequence(1)<800&&frequence(1)>740))
            fprintf('6');
        elseif((frequence(1)<1239&&frequence(1)>1179&&frequence(2)<882&&frequence(2)>822)||(frequence(2)<1239&&frequence(2)>1179&&frequence(1)<882&&frequence(1)>822))
            fprintf('7');
        elseif((frequence(1)<1366&&frequence(1)>1306&&frequence(2)<882&&frequence(2)>822)||(frequence(2)<1366&&frequence(2)>1306&&frequence(1)<882&&frequence(1)>822))
            fprintf('8');
        elseif((frequence(1)<1507&&frequence(1)>1447&&frequence(2)<882&&frequence(2)>822)||(frequence(2)<1507&&frequence(2)>1447&&frequence(1)<882&&frenquence(1)>822))
            fprintf('9');
        elseif((frequence(1)<1366&&frequence(1)>1306&&frequence(2)<971&&frequence(2)>911)||(frequence(2)<1366&&frequence(2)>1306&&frequence(1)<971&&frenquence(1)>911))
            fprintf('0');
        end
        fprintf(" ");
end